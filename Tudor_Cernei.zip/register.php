<?php
function validateName($name) {
    // Verifică dacă numele este gol
    if (empty($name)) {
        return "Numele este obligatoriu.";
    }

    // Verifică dacă numele conține doar litere și spații
    if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
        return "Numele poate conține doar litere și spații.";
    }

    return "";
}

function validateEmail($email) {
    // Verifică dacă adresa de email este goală
    if (empty($email)) {
        return "Adresa de email este obligatorie.";
    }

    // Verifică dacă adresa de email este validă
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "Adresa de email nu este validă.";
    }

    return "";
}

function validatePassword($password) {
    // Verifică dacă parola este goală
    if (empty($password)) {
        return "Parola este obligatorie.";
    }

    // Verifică dacă parola are cel puțin 8 caractere
    if (strlen($password) < 8) {
        return "Parola trebuie să conțină cel puțin 8 caractere.";
    }

    return "";
}

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$servername = "localhost";
$username = "root";
$db_password = "";
$database = "baza_date1";

// Create connection
$conn = new mysqli($servername, $username, $db_password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validează câmpurile
$nameError = validateName($name);
$emailError = validateEmail($email);
$passwordError = validatePassword($password);

if (empty($nameError) && empty($emailError) && empty($passwordError)) {
    // Toate câmpurile sunt valide, efectuăm inserarea în baza de date
    $sql = "INSERT INTO utilizatori (name, email, password) VALUES (?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $email, $hashedPassword);

    if ($stmt->execute()) {
        echo "Înregistrare reușită!";
    } else {
        echo "Eroare: " . $stmt->error;
    }

    $stmt->close();
} else {
    // Există erori de validare, afișăm alerta
    echo "<script>alert('Erori de validare:\\n" .
        "- Nume: " . $nameError . "\\n" .
        "- Email: " . $emailError . "\\n" .
        "- Parolă: " . $passwordError . "');</script>";
}

$conn->close();
?>
