<?php
require 'conf.php';
if (!empty($_SESSION["id"])) {
    header("Location: intermediar.php");
  }
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM utilizatori WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        if (password_verify($password, $hashedPassword)) {
            $_SESSION['email'] = $email; // Store user information in session
            // Redirect to the menu page
            header("Location: meniu.html");
            exit; // Make sure to exit after the redirect
        } else {
            echo "<script> alert('Wrong Password'); </script>";
        }
    } else {
        echo "<script> alert('User Not Registered'); </script>";
    }
}

$conn->close();
?>
