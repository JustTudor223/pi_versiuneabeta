<?php
session_start(); // Start the session
$servername = "localhost";
$username = "root";
$db_password = "";
$database = "baza_date1";

// Create connection
$conn = new mysqli($servername, $username, $db_password, $database);