<?php
session_start();
if (empty($_SESSION["email"])) {
    header("Location: login_form.html");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "baza_date2";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    echo "Failed to connect";
}

if (isset($_POST["add"])) {
    $productId = $_GET["id"];
    $productName = $_POST["hidden_name"];
    $productImage = $_POST["hidden_image"];
    $productPrice = $_POST["hidden_price"];
    $productQuantity = $_POST["quantity"];

    $existingProductQuery = "SELECT * FROM `cart` WHERE description = '$productName'";
    $existingProductResult = mysqli_query($conn, $existingProductQuery);

    if (mysqli_num_rows($existingProductResult) > 0) {
        $existingProduct = mysqli_fetch_assoc($existingProductResult);
        $newQuantity = $existingProduct["quantity"] + $productQuantity;
        $updateQuery = "UPDATE `cart` SET quantity = $newQuantity WHERE description = '$productName'";
        mysqli_query($conn, $updateQuery);
    } else {
        $sql = "INSERT INTO `cart` (`description`, `image`, `price`, `quantity`) VALUES ('$productName', '$productImage', '$productPrice', '$productQuantity');";
        mysqli_query($conn, $sql);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index_styles.css">
    <title>CART</title>
</head>
<body>
    <nav>
        <a href="meniu.html">Inapoi la meniu</a>
        <div>
            <a href="logout.php">LogOut</a>
            <a href="cart.php">Cart</a>
        </div>
    </nav>

    <main>
        <h2>Produse Disponibile</h2>
        <div class="container">
            <?php
            $query = "SELECT * FROM `produse` ORDER BY id ASC";
            $result = mysqli_query($conn, $query);

            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_array($result)) {
            ?>
            <div class="product">
                <form action="index.php?action=add&id=<?php echo $row["id"]; ?>" method="post">
                    <img src="poze/<?php echo $row["image"]; ?>" alt="">
                    <h3><?php echo $row["description"]; ?></h3>
                    <p>pret <?php echo $row["price"]; ?> lei</p>
                    <input type="text" name="quantity" value="1">
                    <input type="hidden" name="hidden_image" value="<?php echo $row["image"]; ?>">
                    <input type="hidden" name="hidden_name" value="<?php echo $row["description"]; ?>">
                    <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                    <input type="submit" name="add" value="Add to Cart">
                </form>
            </div>
            <?php
                }
            }
            ?>
        </div>
    </main>

    <footer></footer>
</body>
</html>
