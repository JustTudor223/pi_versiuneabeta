<?php
require 'conf.php';
$_SESSION = [];
session_unset(); // Unset all session variables
session_destroy(); // Destroy the session
header("Location: login_form.html");